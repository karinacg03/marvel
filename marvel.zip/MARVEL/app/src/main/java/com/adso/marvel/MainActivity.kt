package com.adso.marvel

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import androidx.core.net.toUri
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.adso.marvel.adapter.RecyclerViewAdapter
import com.adso.marvel.data.DataSource
import com.adso.marvel.databinding.ActivityMainBinding
import com.adso.marvel.model.Superheroe
import com.bumptech.glide.Glide

class MainActivity : AppCompatActivity() {
    private lateinit var miRecycler: RecyclerView
    private lateinit var binding: ActivityMainBinding
    lateinit var miRecyclerView: RecyclerViewAdapter
    val miAdapter: RecyclerViewAdapter = RecyclerViewAdapter()




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)



    }
    fun cargarRecycler(){
        miRecycler = binding.rvSuperheroes
        miRecycler.setHasFixedSize(true)
        miRecycler.layoutManager = LinearLayoutManager(this)
        miAdapter.RecyclerViewAdapter(DataSource().getSuperheroes(),this)
        miRecycler.adapter =miAdapter


    }
}
